# ShieldGate: Distributed API Rate Limiter (MERN + Redis + LLD)

Welcome! This project is a **complete, portfolio-ready Full-Stack MERN + Redis implementation** of **Chapter 4: Design a Rate Limiter**, built with clean **Low-Level Design (LLD)** and **SOLID principles**, explained in plain, beginner-friendly language.

---

## 1. What is a Rate Limiter & Why Do We Need It? (Beginner's Analogy)

Imagine a popular nightclub with a bouncer at the door:
- If 10,000 people rush the door at the exact same second, the building will collapse (**Server Overload / DoS Attack**).
- If every person inside orders free expensive drinks non-stop, the owner goes bankrupt (**High Cloud / Third-Party API Costs**).

An **API Rate Limiter** is that smart bouncer sitting in front of your backend servers (as an **API Gateway Middleware**). It checks:
1. **Who is asking?** (User ID, IP Address, Device ID, or Global traffic)
2. **What are they trying to do?** (e.g., `POST /posts`, `POST /login`, `POST /rewards/claim`)
3. **Have they exceeded their quota?**
   - **Allowed (`HTTP 200 OK`)**: Let the request pass to the Express controller.
   - **Blocked (`HTTP 429 Too Many Requests`)**: Stop the request immediately (or put it in a background queue to process later) and tell the user when they can try again using HTTP headers!

---

## 2. Low-Level Design (LLD) Principles & Design Patterns Used

Interviewers love seeing clean Object-Oriented / Modular Low-Level Design instead of one giant `if-else` file. Here is how this codebase is architected:

| Design Pattern / Principle | Where It Is Used | Beginner Explanation |
| :--- | :--- | :--- |
| **Strategy Pattern** (+ Open/Closed Principle) | `backend/src/strategies/*` | All 5 rate-limiting algorithms (`TokenBucket`, `LeakyBucket`, `FixedWindow`, `SlidingWindowLog`, `SlidingWindowCounter`) follow the exact same `.consume(key, rule)` contract (`IRateLimiterStrategy`). You can swap algorithms at runtime without changing a single line of middleware code! |
| **Factory Pattern** | `backend/src/factories/RateLimiterStrategyFactory.js` | Takes a rule's algorithm name (e.g., `"token_bucket"`) and returns the matching Strategy instance. |
| **Adapter / Repository Pattern** (+ Dependency Inversion) | `backend/src/storage/*` | The algorithms don't care whether counters live in **Redis** (`RedisStorageAdapter`) or **Local RAM** (`InMemoryStorageAdapter`). Both implement `IStorageAdapter`. |
| **Decorator / Circuit Breaker Pattern** (High Fault Tolerance) | `backend/src/storage/FaultTolerantStorageDecorator.js` | What if the Redis server crashes? As required in Chapter 4 (*"High fault tolerance"*), this wrapper catches Redis failures and automatically degrades to local in-memory limiting or Fail-Open mode so your entire website never goes down! |
| **Chain of Responsibility (Middleware)** | `backend/src/middleware/rateLimiterMiddleware.js` | Intercepts every HTTP request, resolves the matching rule, checks the counter, attaches `X-Ratelimit-*` headers, and either calls `next()`, enqueues the request, or returns `HTTP 429`. |

---

## 3. All 5 Rate Limiting Algorithms Explained Simply

### 1. Token Bucket (Used by Amazon & Stripe)
- **How it works**: Imagine a bucket that holds at most `capacity` tokens (e.g., 4 tokens). Every second, a refiller adds `refillRate` tokens (e.g., 2 tokens/sec). Each HTTP request takes 1 token. If the bucket is empty (`0` tokens), the request is rejected (`429`).
- **Pros**: Memory-efficient and **allows short bursts of traffic** (e.g., a user clicking rapidly for 1 second).
- **Cons**: Two parameters (`bucketSize` and `refillRate`) require careful tuning.

### 2. Leaking Bucket (Used by Shopify)
- **How it works**: Imagine a bucket with a tiny hole at the bottom that drips water at a **strictly constant speed** (`outflowRate`). Requests enter a FIFO (First-In-First-Out) queue of size `bucketSize`. If the queue is full, new requests overflow and get rejected (`429`).
- **Pros**: Guarantees a **smooth, predictable processing rate** for downstream servers.
- **Cons**: A sudden burst fills the queue with old requests, delaying newer requests.

### 3. Fixed Window Counter
- **How it works**: Divides time into fixed chunks (e.g., `12:00:00 - 12:01:00`). Every request increments an integer counter (`INCR`) with an expiration (`EXPIRE`). If `counter > limit`, reject.
- **Pros**: Simplest and uses the least memory (1 integer per key).
- **Cons**: **Boundary Traffic Spike Problem (Figure 4-9)**! If the limit is 5 req/min, a user can send 5 requests at `12:00:59` and 5 more at `12:01:01`—sending 10 requests in 2 seconds (2x the allowed rate!).

### 4. Sliding Window Log (Used by ClassDojo)
- **How it works**: Stores the exact millisecond timestamp of every request inside a Redis Sorted Set (`ZSET`). When a request arrives at time `now`, it deletes all timestamps older than `now - windowMs` (`ZREMRANGEBYSCORE`), adds `now` (`ZADD`), and counts how many timestamps remain (`ZCARD`).
- **Pros**: **100% accurate** across any rolling window—completely solves the boundary spike bug!
- **Cons**: High memory footprint because every single timestamp is stored.

### 5. Sliding Window Counter (Used by Cloudflare)
- **How it works**: A genius hybrid! Instead of storing every timestamp, it only keeps two integers: `previousWindowCount` and `currentWindowCount`. If we are 30% into the current minute, the rolling window overlaps 70% with the previous minute:
  `estimatedCount = currentWindowCount + Math.floor(previousWindowCount * 0.70)`
- **Pros**: Extremely memory-efficient (only 2 numbers) and smooths out boundary spikes (99.997% accuracy across 400M requests per Cloudflare's study).
- **Cons**: Slight approximation because it assumes requests in the previous window were evenly spaced.

---

## 4. Solving Distributed Systems Challenges (Chapter 4 Deep Dive)

1. **Race Conditions (Figure 4-14)**:
   - *Problem*: If Server A and Server B both read `counter = 3` from Redis at the same millisecond, both calculate `3 + 1 = 4` and write `4` back—even though 2 requests happened and the counter should be `5`!
   - *Solution*: Never do `GET` in Node.js and `SET` later. We use **Redis Atomic Lua Scripts (`EVAL`)** in `backend/src/lua/scripts.js`. Redis runs Lua scripts single-threaded and atomically, so two requests can never interleave!
2. **Synchronization Across Stateless Servers (Figure 4-15 & 4-16)**:
   - *Problem*: Load balancers route User 1 to API Server 1 on request #1, and API Server 2 on request #2.
   - *Solution*: All stateless Express servers talk to a **centralized Redis cluster** (`RedisStorageAdapter`).

---

## 5. Folder Structure

```text
mern-rate-limiter-lld/
├── docker-compose.yml                        # Spins up MongoDB, Redis, Express API, React UI
├── README.md                                 # Complete System Design & LLD Beginner Guide
├── backend/
│   ├── package.json
│   ├── src/
│   │   ├── config/
│   │   │   └── defaultRules.json             # Lyft-style declarative rate limit rules
│   │   ├── interfaces/
│   │   │   ├── IRateLimiterStrategy.js       # Strategy Pattern contract
│   │   │   └── IStorageAdapter.js            # Storage Repository contract
│   │   ├── lua/
│   │   │   └── scripts.js                    # Atomic Redis Lua scripts (prevents race conditions)
│   │   ├── strategies/
│   │   │   ├── TokenBucketStrategy.js        # Algorithm 1: Token Bucket
│   │   │   ├── LeakyBucketStrategy.js        # Algorithm 2: Leaking Bucket
│   │   │   ├── FixedWindowStrategy.js        # Algorithm 3: Fixed Window Counter
│   │   │   ├── SlidingWindowLogStrategy.js   # Algorithm 4: Sliding Window Log
│   │   │   └── SlidingWindowCounterStrategy.js # Algorithm 5: Sliding Window Counter
│   │   ├── factories/
│   │   │   └── RateLimiterStrategyFactory.js # Factory Pattern for instantiating strategies
│   │   ├── storage/
│   │   │   ├── InMemoryStorageAdapter.js     # Fast local memory adapter (for dev/fallback)
│   │   │   ├── RedisStorageAdapter.js        # Distributed Redis adapter running Lua scripts
│   │   │   └── FaultTolerantStorageDecorator.js # Circuit-Breaker wrapper for Redis outages
│   │   ├── models/
│   │   │   ├── RateLimitRule.model.js        # Mongoose Schema for dynamic rules
│   │   │   └── RateLimitMetric.model.js      # Mongoose Schema for analytics/monitoring
│   │   ├── services/
│   │   │   ├── RuleEngineService.js          # Caches disk/DB rules in memory (Worker pattern)
│   │   │   └── RequestQueueService.js        # Side-queue for throttled orders (async retry)
│   │   ├── middleware/
│   │   │   └── rateLimiterMiddleware.js      # Express Gateway Middleware (sets 429 & headers)
│   │   ├── routes/
│   │   │   └── api.routes.js                 # Protected demo routes + Admin rule/metrics APIs
│   │   └── server.js                         # Express + Mongo + Redis entry point
│   └── tests/
│       └── rateLimiter.test.js               # Zero-dependency automated test suite
└── frontend/
    ├── package.json
    └── src/
        ├── api/
        │   └── clientWithBackoff.js          # Client best practices: Cache + Exponential Backoff
        └── App.jsx                           # React Dashboard & Live Traffic Simulator
```

---

## 6. Quick Start

### Run the Automated LLD Verification Tests (Zero Dependencies Needed!)
```bash
node backend/tests/rateLimiter.test.js
```

### Run Full Stack with Docker Compose
```bash
docker-compose up --build
```
