const { TokenBucketStrategy } = require('../strategies/TokenBucketStrategy');
const { LeakyBucketStrategy } = require('../strategies/LeakyBucketStrategy');
const { FixedWindowStrategy } = require('../strategies/FixedWindowStrategy');
const { SlidingWindowLogStrategy } = require('../strategies/SlidingWindowLogStrategy');
const { SlidingWindowCounterStrategy } = require('../strategies/SlidingWindowCounterStrategy');

/**
 * ============================================================================
 * LOW-LEVEL DESIGN (LLD): FACTORY PATTERN
 * ============================================================================
 * Centralizes creation of all 5 rate limiting strategy objects and caches
 * their instances so we don't allocate new objects on every HTTP request.
 */
class RateLimiterStrategyFactory {
  constructor(storageAdapter) {
    this.storage = storageAdapter;
    this.strategies = new Map([
      ['token_bucket', new TokenBucketStrategy(this.storage)],
      ['leaky_bucket', new LeakyBucketStrategy(this.storage)],
      ['fixed_window', new FixedWindowStrategy(this.storage)],
      ['sliding_window_log', new SlidingWindowLogStrategy(this.storage)],
      ['sliding_window_counter', new SlidingWindowCounterStrategy(this.storage)],
    ]);
  }

  /**
   * Returns the concrete Strategy instance for a given algorithm name.
   * @param {string} algorithmName
   * @returns {IRateLimiterStrategy}
   */
  getStrategy(algorithmName) {
    const normalized = String(algorithmName || 'token_bucket').toLowerCase().trim();
    const strategy = this.strategies.get(normalized);
    if (!strategy) {
      throw new Error(
        `Unsupported rate limiting algorithm "${algorithmName}". Supported: ${Array.from(this.strategies.keys()).join(', ')}`
      );
    }
    return strategy;
  }
}

module.exports = { RateLimiterStrategyFactory };
