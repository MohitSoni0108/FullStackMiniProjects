/**
 * ============================================================================
 * LOW-LEVEL DESIGN (LLD): STRATEGY PATTERN INTERFACE
 * ============================================================================
 * Why do we use this interface?
 * In SOLID principles, the Open/Closed Principle (OCP) states that software
 * entities should be "open for extension, but closed for modification."
 *
 * By defining `IRateLimiterStrategy`, our Express Middleware doesn't need a
 * messy `if (algo === 'token') ... else if (algo === 'fixed')` block.
 * Every algorithm implements `.consume(clientKey, rule, nowMs)` and returns a
 * standardized `RateLimitDecision` object!
 */

class RateLimitDecision {
  /**
   * @param {Object} params
   * @param {boolean} params.allowed - Did the request pass the rate limiter?
   * @param {number} params.limit - X-Ratelimit-Limit (Maximum quota in window/bucket)
   * @param {number} params.remaining - X-Ratelimit-Remaining (Remaining requests allowed)
   * @param {number} params.retryAfterSec - X-Ratelimit-Retry-After (Seconds until next allowed request)
   * @param {string} params.algorithm - Name of the algorithm that processed this request
   * @param {Object} [params.debugState] - Extra internal state (tokens, queue size, timestamps) for learning/monitoring
   */
  constructor({ allowed, limit, remaining, retryAfterSec, algorithm, debugState = {} }) {
    this.allowed = Boolean(allowed);
    this.limit = Number(limit);
    this.remaining = Math.max(0, Number(remaining));
    this.retryAfterSec = Math.max(0, Number(retryAfterSec));
    this.algorithm = algorithm;
    this.debugState = debugState;
  }

  /**
   * Generates the exact HTTP headers specified in Chapter 4 ("Rate limiter headers")
   */
  toHttpHeaders() {
    const headers = {
      'X-Ratelimit-Limit': String(this.limit),
      'X-Ratelimit-Remaining': String(this.remaining),
    };
    if (!this.allowed || this.retryAfterSec > 0) {
      headers['X-Ratelimit-Retry-After'] = String(this.retryAfterSec);
    }
    return headers;
  }
}

class IRateLimiterStrategy {
  /**
   * @param {IStorageAdapter} storageAdapter - Injected storage (Redis or In-Memory)
   */
  constructor(storageAdapter) {
    if (new.target === IRateLimiterStrategy) {
      throw new Error('IRateLimiterStrategy is an abstract interface and cannot be instantiated directly.');
    }
    this.storage = storageAdapter;
  }

  /**
   * Consumes 1 request quota for the given `key` and `rule`.
   * @param {string} key - Unique bucket key, e.g., "rl:social:user_101"
   * @param {Object} rule - Rate limit rule configuration
   * @param {number} [nowMs=Date.now()] - Current timestamp in milliseconds (injectable for deterministic unit testing!)
   * @returns {Promise<RateLimitDecision>}
   */
  async consume(key, rule, nowMs = Date.now()) {
    throw new Error('Method consume(key, rule, nowMs) must be implemented by concrete strategy class.');
  }
}

module.exports = {
  IRateLimiterStrategy,
  RateLimitDecision,
};
