/**
 * ============================================================================
 * LOW-LEVEL DESIGN (LLD): REPOSITORY / ADAPTER INTERFACE
 * ============================================================================
 * Why do we need `IStorageAdapter`?
 * Dependency Inversion Principle (DIP): High-level rate limiting algorithms
 * should not depend directly on low-level Redis drivers (`ioredis`).
 *
 * By abstracting storage operations behind `IStorageAdapter`, we can:
 * 1. Use `RedisStorageAdapter` in production across distributed servers.
 * 2. Use `InMemoryStorageAdapter` for local unit testing or when Redis crashes!
 */

class IStorageAdapter {
  constructor() {
    if (new.target === IStorageAdapter) {
      throw new Error('IStorageAdapter is an abstract interface.');
    }
  }

  async runTokenBucket(key, capacity, refillRatePerSec, nowMs, requestedTokens = 1) {
    throw new Error('Not implemented');
  }

  async runLeakyBucket(key, capacity, outflowRatePerSec, nowMs) {
    throw new Error('Not implemented');
  }

  async runFixedWindow(key, limit, windowSec, nowMs) {
    throw new Error('Not implemented');
  }

  async runSlidingWindowLog(key, limit, windowSec, nowMs) {
    throw new Error('Not implemented');
  }

  async runSlidingWindowCounter(key, limit, windowSec, nowMs) {
    throw new Error('Not implemented');
  }
}

module.exports = { IStorageAdapter };
