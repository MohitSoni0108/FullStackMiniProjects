/**
 * ============================================================================
 * CHAPTER 4 DEEP DIVE: SOLVING RACE CONDITIONS WITH REDIS LUA SCRIPTS
 * ============================================================================
 * Why Lua Scripts?
 * In Chapter 4 (Figure 4-14), if two concurrent servers read `counter = 3` from
 * Redis at the same time, both increment it to `4` and write `4` back (a classic
 * Race Condition!). Using locks slows down HTTP responses terribly.
 *
 * Redis executes a Lua script (`EVAL`) as a SINGLE ATOMIC OPERATION. No other
 * request can run in Redis while the script is executing, giving us 100% accuracy
 * at sub-millisecond speed without slow distributed locks!
 */

/**
 * 1. TOKEN BUCKET LUA SCRIPT
 * KEYS[1] = bucket key
 * ARGV[1] = bucket capacity (max tokens)
 * ARGV[2] = refill rate (tokens added per second)
 * ARGV[3] = current timestamp in milliseconds
 * ARGV[4] = tokens requested (default 1)
 */
const TOKEN_BUCKET_LUA = `
local key = KEYS[1]
local capacity = tonumber(ARGV[1])
local refill_rate = tonumber(ARGV[2])
local now_ms = tonumber(ARGV[3])
local requested = tonumber(ARGV[4])

local data = redis.call("HMGET", key, "tokens", "last_refill_ms")
local tokens = tonumber(data[1])
local last_refill_ms = tonumber(data[2])

if tokens == nil then
  tokens = capacity
  last_refill_ms = now_ms
else
  local elapsed_sec = math.max(0, (now_ms - last_refill_ms) / 1000.0)
  local refilled = elapsed_sec * refill_rate
  tokens = math.min(capacity, tokens + refilled)
  last_refill_ms = now_ms
end

local allowed = 0
local retry_after = 0

if tokens >= requested then
  tokens = tokens - requested
  allowed = 1
else
  local deficit = requested - tokens
  retry_after = math.ceil(deficit / refill_rate)
end

local ttl_sec = math.max(60, math.ceil((capacity / refill_rate) * 2))
redis.call("HMSET", key, "tokens", tokens, "last_refill_ms", last_refill_ms)
redis.call("EXPIRE", key, ttl_sec)

return { allowed, math.floor(tokens), retry_after }
`;

/**
 * 2. LEAKING BUCKET (FIFO QUEUE OUTFLOW) LUA SCRIPT
 * KEYS[1] = bucket queue key
 * ARGV[1] = bucket capacity (queue size)
 * ARGV[2] = outflow rate (requests leaked/processed per second)
 * ARGV[3] = current timestamp in milliseconds
 */
const LEAKY_BUCKET_LUA = `
local key = KEYS[1]
local capacity = tonumber(ARGV[1])
local outflow_rate = tonumber(ARGV[2])
local now_ms = tonumber(ARGV[3])

local data = redis.call("HMGET", key, "water", "last_leak_ms")
local water = tonumber(data[1])
local last_leak_ms = tonumber(data[2])

if water == nil then
  water = 0
  last_leak_ms = now_ms
else
  local elapsed_sec = math.max(0, (now_ms - last_leak_ms) / 1000.0)
  local leaked = elapsed_sec * outflow_rate
  water = math.max(0, water - leaked)
  last_leak_ms = now_ms
end

local allowed = 0
local retry_after = 0

if (water + 1) <= capacity then
  water = water + 1
  allowed = 1
else
  local overflow = (water + 1) - capacity
  retry_after = math.ceil(overflow / outflow_rate)
end

local remaining = math.max(0, math.floor(capacity - water))
local ttl_sec = math.max(60, math.ceil((capacity / outflow_rate) * 2))
redis.call("HMSET", key, "water", water, "last_leak_ms", last_leak_ms)
redis.call("EXPIRE", key, ttl_sec)

return { allowed, remaining, retry_after }
`;

/**
 * 3. FIXED WINDOW COUNTER LUA SCRIPT
 * Uses Redis INCR and EXPIRE atomically inside one script so the key never
 * gets stuck without an expiration if a server crashes between INCR and EXPIRE!
 */
const FIXED_WINDOW_LUA = `
local key = KEYS[1]
local limit = tonumber(ARGV[1])
local window_sec = tonumber(ARGV[2])

local current = redis.call("INCR", key)
if current == 1 then
  redis.call("EXPIRE", key, window_sec)
end

local ttl = redis.call("TTL", key)
if ttl < 0 then
  ttl = window_sec
end

local allowed = 0
if current <= limit then
  allowed = 1
end

local remaining = math.max(0, limit - current)
local retry_after = 0
if allowed == 0 then
  retry_after = ttl
end

return { allowed, remaining, retry_after, current }
`;

/**
 * 4. SLIDING WINDOW LOG LUA SCRIPT (Redis Sorted Sets - ZSET)
 * Reference [8] from Chapter 4: ClassDojo Rolling Rate Limiter with Sorted Sets.
 * Note: As described in Chapter 4 (Figure 4-10), even if a request is rejected,
 * its timestamp is inserted into the log, or pruned on the next window check.
 */
const SLIDING_WINDOW_LOG_LUA = `
local key = KEYS[1]
local limit = tonumber(ARGV[1])
local window_ms = tonumber(ARGV[2])
local now_ms = tonumber(ARGV[3])
local req_id = ARGV[4]

local window_start = now_ms - window_ms

-- Step 1: Remove outdated timestamps older than start of current rolling window
redis.call("ZREMRANGEBYSCORE", key, "-inf", window_start)

-- Step 2: Add timestamp of the new request to the sorted set log
redis.call("ZADD", key, now_ms, req_id)

-- Step 3: Count total timestamps inside the rolling window
local count = redis.call("ZCARD", key)
redis.call("PEXPIRE", key, window_ms)

local allowed = 0
local retry_after = 0
if count <= limit then
  allowed = 1
else
  local oldest = redis.call("ZRANGE", key, 0, 0, "WITHSCORES")
  if oldest[2] ~= nil then
    local oldest_ms = tonumber(oldest[2])
    retry_after = math.max(1, math.ceil((oldest_ms + window_ms - now_ms) / 1000.0))
  else
    retry_after = math.ceil(window_ms / 1000.0)
  end
end

local remaining = math.max(0, limit - count)
return { allowed, remaining, retry_after, count }
`;

/**
 * 5. SLIDING WINDOW COUNTER LUA SCRIPT (Cloudflare Hybrid Approximation)
 * Formula from Chapter 4 (Figure 4-11):
 * estimated = current_window_requests + floor(previous_window_requests * overlap_ratio)
 */
const SLIDING_WINDOW_COUNTER_LUA = `
local curr_key = KEYS[1]
local prev_key = KEYS[2]
local limit = tonumber(ARGV[1])
local window_sec = tonumber(ARGV[2])
local overlap_ratio = tonumber(ARGV[3])

local prev_count = tonumber(redis.call("GET", prev_key) or "0")
local curr_count = tonumber(redis.call("GET", curr_key) or "0")

local weighted_prev = math.floor(prev_count * overlap_ratio)
local estimated_before = curr_count + weighted_prev

local allowed = 0
local retry_after = 0

if (estimated_before + 1) <= limit then
  allowed = 1
  curr_count = redis.call("INCR", curr_key)
  if curr_count == 1 then
    redis.call("EXPIRE", curr_key, window_sec * 2)
  end
  estimated_before = estimated_before + 1
else
  retry_after = math.max(1, math.ceil(window_sec * overlap_ratio))
end

local remaining = math.max(0, limit - estimated_before)
return { allowed, remaining, retry_after, estimated_before }
`;

module.exports = {
  TOKEN_BUCKET_LUA,
  LEAKY_BUCKET_LUA,
  FIXED_WINDOW_LUA,
  SLIDING_WINDOW_LOG_LUA,
  SLIDING_WINDOW_COUNTER_LUA,
};
