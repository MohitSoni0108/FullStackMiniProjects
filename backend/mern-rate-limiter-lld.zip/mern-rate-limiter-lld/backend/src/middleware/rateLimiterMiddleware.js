/**
 * ============================================================================
 * CHAPTER 4 API GATEWAY / EXPRESS RATE LIMITER MIDDLEWARE
 * ============================================================================
 * Responsibilities:
 * 1. Extract client descriptors (User ID, IP address, Device ID, custom headers/body).
 * 2. Match the request against the cached RuleEngineService.
 * 3. Select the right algorithm via `RateLimiterStrategyFactory`.
 * 4. Execute `.consume(bucketKey, rule)` atomically via the Storage Adapter.
 * 5. Attach standard HTTP Rate Limit Headers:
 *    - `X-Ratelimit-Limit`
 *    - `X-Ratelimit-Remaining`
 *    - `X-Ratelimit-Retry-After`
 * 6. Handle throttled requests:
 *    - Soft Rate Limiting (`rule.softLimit === true`): Log warning & allow burst.
 *    - Enqueue Mode (`rule.exceedAction === 'enqueue'`): Save to `RequestQueueService` & return HTTP 202/429 info.
 *    - Hard Reject Mode: Return `HTTP 429 Too Many Requests` with clear JSON error.
 */
function createRateLimiterMiddleware({
  ruleEngine,
  strategyFactory,
  requestQueue,
  metricsCollector = [],
}) {
  return async function rateLimiterMiddleware(req, res, next) {
    const startHr = process.hrtime.bigint();

    // 1. Build descriptors from request headers, query, body, and IP
    const descriptors = {
      ip_address: req.headers['x-forwarded-for'] || req.ip || '127.0.0.1',
      user_id: req.headers['x-user-id'] || req.body?.userId || 'anonymous',
      device_id: req.headers['x-device-id'] || req.body?.deviceId || 'default_device',
      auth_type: req.body?.authType || req.headers['x-auth-type'] || 'login',
      message_type: req.body?.messageType || req.headers['x-message-type'] || 'marketing',
    };

    // 2. Match rule from cache
    const matched = ruleEngine.matchRule({
      endpoint: req.path,
      method: req.method,
      descriptors,
    });

    // If no rule applies to this route, allow straight through
    if (!matched) {
      return next();
    }

    const { rule, bucketKey } = matched;

    try {
      // 3. Get the concrete Strategy via Factory Pattern
      const strategy = strategyFactory.getStrategy(rule.algorithm);

      // 4. Execute rate limit check
      const decision = await strategy.consume(bucketKey, rule);

      // 5. Attach Chapter 4 HTTP headers (`X-Ratelimit-Limit`, `X-Ratelimit-Remaining`, `X-Ratelimit-Retry-After`)
      const headers = decision.toHttpHeaders();
      for (const [headerName, headerVal] of Object.entries(headers)) {
        res.setHeader(headerName, headerVal);
      }

      const latencyMs = Number(process.hrtime.bigint() - startHr) / 1e6;

      // Record metric for Chapter 4 Monitoring
      const metricEntry = {
        timestamp: new Date().toISOString(),
        ruleId: rule.id,
        domain: rule.domain,
        algorithm: rule.algorithm,
        bucketKey,
        allowed: decision.allowed,
        remaining: decision.remaining,
        retryAfterSec: decision.retryAfterSec,
        latencyMs: Number(latencyMs.toFixed(3)),
      };
      metricsCollector.unshift(metricEntry);
      if (metricsCollector.length > 200) metricsCollector.pop();

      if (decision.allowed) {
        req.rateLimitDecision = decision;
        return next();
      }

      // Soft Rate Limiting (Chapter 4 Step 4: "Soft: Requests can exceed the threshold for a short period")
      if (rule.softLimit) {
        res.setHeader('X-Ratelimit-Soft-Warning', 'Threshold exceeded; allowed under soft rate limit policy');
        req.rateLimitDecision = { ...decision, softAllowed: true };
        return next();
      }

      // Enqueue Rate-Limited Requests (Chapter 4: "enqueue the rate-limited requests to be processed later")
      let queueResult = null;
      if (rule.exceedAction === 'enqueue' && requestQueue) {
        queueResult = requestQueue.enqueue({
          endpoint: req.path,
          method: req.method,
          descriptors,
          body: req.body,
        });
      }

      // Return HTTP 429 Too Many Requests
      return res.status(429).json({
        error: 'Too Many Requests',
        statusCode: 429,
        message: `Rate limit exceeded for domain "${rule.domain}" using ${rule.algorithm}. Please wait ${decision.retryAfterSec} second(s) before retrying.`,
        ruleId: rule.id,
        algorithm: decision.algorithm,
        limit: decision.limit,
        remaining: decision.remaining,
        retryAfterSeconds: decision.retryAfterSec,
        enqueuedForLater: queueResult ? queueResult.queued : false,
        queueDetails: queueResult,
      });
    } catch (err) {
      // High Fault Tolerance: Never crash the API server if an unexpected error occurs in rate limiting
      return next();
    }
  };
}

module.exports = { createRateLimiterMiddleware };
