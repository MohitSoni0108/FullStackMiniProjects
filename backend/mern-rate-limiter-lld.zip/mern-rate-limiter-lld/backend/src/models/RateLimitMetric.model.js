const mongoose = require('mongoose');

/**
 * Chapter 4 "Monitoring":
 * Gathers analytics data to check whether:
 * 1. The rate limiting algorithm is effective.
 * 2. The rate limiting rules are effective (not dropping too many valid requests).
 */
const RateLimitMetricSchema = new mongoose.Schema(
  {
    ruleId: { type: String, required: true, index: true },
    domain: { type: String, required: true },
    algorithm: { type: String, required: true },
    clientIdentifier: { type: String, required: true },
    allowed: { type: Boolean, required: true },
    enqueued: { type: Boolean, default: false },
    softAllowed: { type: Boolean, default: false },
    remaining: { type: Number },
    retryAfterSec: { type: Number },
    latencyMs: { type: Number },
  },
  { timestamps: true }
);

module.exports = mongoose.models.RateLimitMetric || mongoose.model('RateLimitMetric', RateLimitMetricSchema);
