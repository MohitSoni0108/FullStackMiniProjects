const mongoose = require('mongoose');

/**
 * Stores Lyft-style Rate Limiting Rules in MongoDB so admins can update rules
 * dynamically from the React Dashboard without redeploying the server!
 */
const RateLimitRuleSchema = new mongoose.Schema(
  {
    id: { type: String, required: true, unique: true },
    domain: { type: String, required: true, index: true },
    endpoint: { type: String, required: true },
    method: { type: String, default: 'ANY' },
    descriptorKey: { type: String, required: true }, // e.g., 'user_id', 'ip_address', 'device_id', 'message_type'
    descriptorValue: { type: String, default: '*' }, // '*' matches any value for that key, or specific like 'marketing'
    algorithm: {
      type: String,
      enum: [
        'token_bucket',
        'leaky_bucket',
        'fixed_window',
        'sliding_window_log',
        'sliding_window_counter',
      ],
      default: 'token_bucket',
    },
    limit: { type: Number, required: true, min: 1 },
    windowSec: { type: Number, required: true, min: 1 },
    bucketSize: { type: Number },
    refillRate: { type: Number },
    outflowRate: { type: Number },
    exceedAction: {
      type: String,
      enum: ['reject', 'enqueue'],
      default: 'reject',
    },
    softLimit: { type: Boolean, default: false },
    description: { type: String, default: '' },
  },
  { timestamps: true }
);

module.exports = mongoose.models.RateLimitRule || mongoose.model('RateLimitRule', RateLimitRuleSchema);
