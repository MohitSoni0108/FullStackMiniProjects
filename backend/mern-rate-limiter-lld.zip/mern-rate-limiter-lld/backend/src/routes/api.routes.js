const express = require('express');

function createApiRouter({ ruleEngine, requestQueue, metricsCollector, storageAdapter }) {
  const router = express.Router();

  // Protected Business Endpoints (Chapter 4 Examples)
  router.post('/v1/posts', (req, res) => {
    res.status(200).json({
      success: true,
      endpoint: 'POST /api/v1/posts',
      message: 'Post published! (Protected by Token Bucket: max 2 posts/sec per user)',
      rateLimit: req.rateLimitDecision,
    });
  });

  router.post('/v1/accounts', (req, res) => {
    res.status(200).json({
      success: true,
      endpoint: 'POST /api/v1/accounts',
      message: 'Account created! (Protected by Fixed Window Counter: max 10 accounts/day per IP)',
      rateLimit: req.rateLimitDecision,
    });
  });

  router.post('/v1/rewards/claim', (req, res) => {
    res.status(200).json({
      success: true,
      endpoint: 'POST /api/v1/rewards/claim',
      message: 'Reward claimed! (Protected by Sliding Window Log: max 5 claims/week per device)',
      rateLimit: req.rateLimitDecision,
    });
  });

  router.post('/v1/auth/login', (req, res) => {
    res.status(200).json({
      success: true,
      endpoint: 'POST /api/v1/auth/login',
      message: 'Login successful! (Protected by Sliding Window Counter: max 5 logins/min)',
      rateLimit: req.rateLimitDecision,
    });
  });

  router.post('/v1/messages/marketing', (req, res) => {
    res.status(200).json({
      success: true,
      endpoint: 'POST /api/v1/messages/marketing',
      message: 'Marketing message dispatched! (Protected by Leaky Bucket + Async Queue)',
      rateLimit: req.rateLimitDecision,
    });
  });

  // Admin & Monitoring Endpoints
  router.get('/admin/rules', (req, res) => {
    res.json({ rules: ruleEngine.getAllRules() });
  });

  router.post('/admin/rules', (req, res) => {
    const updated = ruleEngine.upsertRule(req.body);
    res.json({ success: true, rule: updated });
  });

  router.get('/admin/metrics', (req, res) => {
    res.json({
      recentDecisions: metricsCollector.slice(0, 50),
      queuedRequests: requestQueue.getQueueSnapshot(),
      storageHealth: {
        isPrimaryHealthy: storageAdapter.isPrimaryHealthy ?? true,
        fallbackCount: storageAdapter.fallbackCount ?? 0,
      },
    });
  });

  return router;
}

module.exports = { createApiRouter };
