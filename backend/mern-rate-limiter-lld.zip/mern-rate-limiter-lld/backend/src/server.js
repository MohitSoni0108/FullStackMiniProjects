const express = require('express');
const cors = require('cors');
const { InMemoryStorageAdapter } = require('./storage/InMemoryStorageAdapter');
const { FaultTolerantStorageDecorator } = require('./storage/FaultTolerantStorageDecorator');
const { RateLimiterStrategyFactory } = require('./factories/RateLimiterStrategyFactory');
const { RuleEngineService } = require('./services/RuleEngineService');
const { RequestQueueService } = require('./services/RequestQueueService');
const { createRateLimiterMiddleware } = require('./middleware/rateLimiterMiddleware');
const { createApiRouter } = require('./routes/api.routes');

function createApp() {
  const app = express();
  app.use(cors());
  app.use(express.json());

  const memoryStorage = new InMemoryStorageAdapter();
  const faultTolerantStorage = new FaultTolerantStorageDecorator(
    memoryStorage,
    memoryStorage,
    process.env.FALLBACK_MODE || 'memory'
  );

  const strategyFactory = new RateLimiterStrategyFactory(faultTolerantStorage);
  const ruleEngine = new RuleEngineService();
  const requestQueue = new RequestQueueService();
  const metricsCollector = [];

  // Register Rate Limiter Gateway Middleware
  app.use(
    '/api',
    createRateLimiterMiddleware({
      ruleEngine,
      strategyFactory,
      requestQueue,
      metricsCollector,
    })
  );

  app.use(
    '/api',
    createApiRouter({
      ruleEngine,
      requestQueue,
      metricsCollector,
      storageAdapter: faultTolerantStorage,
    })
  );

  return { app, memoryStorage, faultTolerantStorage, strategyFactory, ruleEngine, requestQueue };
}

if (require.main === module) {
  const PORT = process.env.PORT || 5000;
  const { app } = createApp();
  app.listen(PORT, () => {
    console.log(`ShieldGate Rate Limiter Server running on http://localhost:${PORT}`);
  });
}

module.exports = { createApp };
