/**
 * ============================================================================
 * CHAPTER 4 EXCEEDING THE RATE LIMIT: SIDE QUEUE FOR THROTTLED ORDERS
 * ============================================================================
 * From Chapter 4:
 * "Depending on the use cases, we may enqueue the rate-limited requests to be
 * processed later. For example, if some orders are rate limited due to system
 * overload, we may keep those orders to be processed later."
 */
class RequestQueueService {
  constructor(maxQueueSize = 500) {
    this.maxQueueSize = maxQueueSize;
    this.queue = [];
  }

  enqueue(requestPayload) {
    if (this.queue.length >= this.maxQueueSize) {
      return { queued: false, reason: 'Queue capacity reached' };
    }
    const item = {
      queueId: `q_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      enqueuedAt: new Date().toISOString(),
      status: 'QUEUED_FOR_ASYNC_PROCESSING',
      ...requestPayload,
    };
    this.queue.push(item);
    return { queued: true, item, position: this.queue.length };
  }

  dequeue() {
    return this.queue.shift() || null;
  }

  getQueueSnapshot() {
    return [...this.queue];
  }
}

module.exports = { RequestQueueService };
