const fs = require('fs');
const path = require('path');

/**
 * ============================================================================
 * CHAPTER 4 DETAILED DESIGN (Figure 4-13): RULE CACHE & BACKGROUND WORKER
 * ============================================================================
 * In Figure 4-13:
 * "Rules are stored on the disk. Workers frequently pull rules from the disk
 * and store them in the cache."
 *
 * This service loads the default Lyft-style rules from disk (`defaultRules.json`),
 * merges any dynamic rules from MongoDB, and keeps them in a fast in-memory
 * cache so the middleware never touches the disk on an incoming HTTP request!
 */
class RuleEngineService {
  constructor() {
    this.rulesCache = new Map();
    this.loadRulesFromDisk();
  }

  loadRulesFromDisk() {
    const filePath = path.join(__dirname, '../config/defaultRules.json');
    const raw = fs.readFileSync(filePath, 'utf-8');
    const rules = JSON.parse(raw);
    for (const rule of rules) {
      this.rulesCache.set(rule.id, rule);
    }
    return this.getAllRules();
  }

  getAllRules() {
    return Array.from(this.rulesCache.values());
  }

  upsertRule(rule) {
    this.rulesCache.set(rule.id, rule);
    return rule;
  }

  /**
   * Matches an incoming HTTP request against cached rules.
   */
  matchRule({ endpoint, method, descriptors = {} }) {
    for (const rule of this.rulesCache.values()) {
      const endpointMatches = rule.endpoint === '*' || endpoint.startsWith(rule.endpoint);
      const methodMatches = rule.method === 'ANY' || rule.method.toUpperCase() === method.toUpperCase();
      if (!endpointMatches || !methodMatches) continue;

      const clientVal = descriptors[rule.descriptorKey];
      if (clientVal === undefined) continue;

      if (rule.descriptorValue === '*' || String(clientVal) === String(rule.descriptorValue)) {
        return {
          rule,
          bucketKey: `${rule.id}:${rule.domain}:${rule.descriptorKey}:${clientVal}`,
        };
      }
    }
    return null;
  }
}

module.exports = { RuleEngineService };
