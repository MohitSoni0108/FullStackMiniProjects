const { IStorageAdapter } = require('../interfaces/IStorageAdapter');

/**
 * ============================================================================
 * LOW-LEVEL DESIGN (LLD): DECORATOR / CIRCUIT BREAKER PATTERN
 * ============================================================================
 * Chapter 4 Requirement:
 * "High fault tolerance. If there are any problems with the rate limiter (for
 * example, a cache server goes offline), it does not affect the entire system."
 *
 * How this works:
 * Wraps the primary `RedisStorageAdapter`. If Redis throws a connection error
 * or times out, it automatically falls back to either:
 *   1. `memory` mode: Uses local `InMemoryStorageAdapter` on each API server.
 *   2. `fail_open` mode: Immediately allows the request (`allowed: true`) so
 *      users are never blocked by an internal Redis outage!
 */
class FaultTolerantStorageDecorator extends IStorageAdapter {
  /**
   * @param {IStorageAdapter} primaryStorage - Typically RedisStorageAdapter
   * @param {IStorageAdapter} fallbackStorage - Typically InMemoryStorageAdapter
   * @param {'memory' | 'fail_open'} [failureMode='memory']
   */
  constructor(primaryStorage, fallbackStorage, failureMode = 'memory') {
    super();
    this.primary = primaryStorage;
    this.fallback = fallbackStorage;
    this.failureMode = failureMode;
    this.isPrimaryHealthy = true;
    this.fallbackCount = 0;
  }

  async _executeWithFallback(methodName, args, defaultLimit = 5) {
    try {
      const res = await this.primary[methodName](...args);
      this.isPrimaryHealthy = true;
      return { ...res, storageUsed: 'primary_redis' };
    } catch (error) {
      this.isPrimaryHealthy = false;
      this.fallbackCount += 1;

      if (this.failureMode === 'fail_open') {
        return {
          allowed: true,
          remaining: defaultLimit,
          retryAfterSec: 0,
          storageUsed: 'fail_open_bypass',
          fallbackReason: error.message,
        };
      }

      const fallbackRes = await this.fallback[methodName](...args);
      return {
        ...fallbackRes,
        storageUsed: 'fallback_memory',
        fallbackReason: error.message,
      };
    }
  }

  runTokenBucket(key, capacity, refillRatePerSec, nowMs, requestedTokens = 1) {
    return this._executeWithFallback('runTokenBucket', [key, capacity, refillRatePerSec, nowMs, requestedTokens], capacity);
  }

  runLeakyBucket(key, capacity, outflowRatePerSec, nowMs) {
    return this._executeWithFallback('runLeakyBucket', [key, capacity, outflowRatePerSec, nowMs], capacity);
  }

  runFixedWindow(key, limit, windowSec, nowMs) {
    return this._executeWithFallback('runFixedWindow', [key, limit, windowSec, nowMs], limit);
  }

  runSlidingWindowLog(key, limit, windowSec, nowMs) {
    return this._executeWithFallback('runSlidingWindowLog', [key, limit, windowSec, nowMs], limit);
  }

  runSlidingWindowCounter(key, limit, windowSec, nowMs) {
    return this._executeWithFallback('runSlidingWindowCounter', [key, limit, windowSec, nowMs], limit);
  }
}

module.exports = { FaultTolerantStorageDecorator };
