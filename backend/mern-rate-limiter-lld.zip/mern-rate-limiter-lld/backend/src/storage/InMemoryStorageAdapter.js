const { IStorageAdapter } = require('../interfaces/IStorageAdapter');

/**
 * ============================================================================
 * IN-MEMORY STORAGE ADAPTER (Local RAM Cache / Fallback Store)
 * ============================================================================
 * Implements the exact same mathematical logic as our Redis Lua scripts so you
 * can run unit tests, local dev, or automatic failover when Redis is offline!
 */
class InMemoryStorageAdapter extends IStorageAdapter {
  constructor() {
    super();
    this.tokenBuckets = new Map();
    this.leakyBuckets = new Map();
    this.fixedWindows = new Map();
    this.slidingLogs = new Map();
  }

  async runTokenBucket(key, capacity, refillRatePerSec, nowMs, requestedTokens = 1) {
    let bucket = this.tokenBuckets.get(key);
    if (!bucket) {
      bucket = { tokens: capacity, lastRefillMs: nowMs };
    } else {
      const elapsedSec = Math.max(0, (nowMs - bucket.lastRefillMs) / 1000);
      const refilled = elapsedSec * refillRatePerSec;
      bucket.tokens = Math.min(capacity, bucket.tokens + refilled);
      bucket.lastRefillMs = nowMs;
    }

    let allowed = false;
    let retryAfterSec = 0;

    if (bucket.tokens >= requestedTokens) {
      bucket.tokens -= requestedTokens;
      allowed = true;
    } else {
      const deficit = requestedTokens - bucket.tokens;
      retryAfterSec = Math.ceil(deficit / refillRatePerSec);
    }

    this.tokenBuckets.set(key, bucket);

    return {
      allowed,
      remaining: Math.floor(bucket.tokens),
      retryAfterSec,
      tokensLeft: Number(bucket.tokens.toFixed(2)),
    };
  }

  async runLeakyBucket(key, capacity, outflowRatePerSec, nowMs) {
    let bucket = this.leakyBuckets.get(key);
    if (!bucket) {
      bucket = { water: 0, lastLeakMs: nowMs };
    } else {
      const elapsedSec = Math.max(0, (nowMs - bucket.lastLeakMs) / 1000);
      const leaked = elapsedSec * outflowRatePerSec;
      bucket.water = Math.max(0, bucket.water - leaked);
      bucket.lastLeakMs = nowMs;
    }

    let allowed = false;
    let retryAfterSec = 0;

    if (bucket.water + 1 <= capacity) {
      bucket.water += 1;
      allowed = true;
    } else {
      const overflow = bucket.water + 1 - capacity;
      retryAfterSec = Math.ceil(overflow / outflowRatePerSec);
    }

    this.leakyBuckets.set(key, bucket);

    return {
      allowed,
      remaining: Math.max(0, Math.floor(capacity - bucket.water)),
      retryAfterSec,
      queueSize: Number(bucket.water.toFixed(2)),
    };
  }

  async runFixedWindow(key, limit, windowSec, nowMs) {
    const windowMs = windowSec * 1000;
    const windowId = Math.floor(nowMs / windowMs);
    const windowKey = `${key}:${windowId}`;

    const currentCount = (this.fixedWindows.get(windowKey) || 0) + 1;
    this.fixedWindows.set(windowKey, currentCount);

    const allowed = currentCount <= limit;
    const remaining = Math.max(0, limit - currentCount);
    const windowEndMs = (windowId + 1) * windowMs;
    const retryAfterSec = allowed ? 0 : Math.max(1, Math.ceil((windowEndMs - nowMs) / 1000));

    return {
      allowed,
      remaining,
      retryAfterSec,
      currentCount,
      windowId,
    };
  }

  async runSlidingWindowLog(key, limit, windowSec, nowMs) {
    const windowMs = windowSec * 1000;
    const windowStartMs = nowMs - windowMs;

    let log = this.slidingLogs.get(key) || [];
    // Step 1: Remove outdated timestamps older than start of current rolling window
    log = log.filter((ts) => ts > windowStartMs);

    // Step 2: Add current timestamp to the log (Chapter 4 Figure 4-10 notes rejected timestamps remain in log)
    log.push(nowMs);
    this.slidingLogs.set(key, log);

    // Step 3: Check if log size is <= allowed count
    const allowed = log.length <= limit;
    const remaining = Math.max(0, limit - log.length);
    let retryAfterSec = 0;
    if (!allowed && log.length > 0) {
      const oldestInWindow = log[0];
      retryAfterSec = Math.max(1, Math.ceil((oldestInWindow + windowMs - nowMs) / 1000));
    }

    return {
      allowed,
      remaining,
      retryAfterSec,
      logSize: log.length,
      timestamps: [...log],
    };
  }

  async runSlidingWindowCounter(key, limit, windowSec, nowMs) {
    const windowMs = windowSec * 1000;
    const currentWindowId = Math.floor(nowMs / windowMs);
    const prevWindowId = currentWindowId - 1;

    const currKey = `${key}:${currentWindowId}`;
    const prevKey = `${key}:${prevWindowId}`;

    const elapsedInCurrentWindowMs = nowMs - currentWindowId * windowMs;
    const positionRatio = elapsedInCurrentWindowMs / windowMs; // e.g., 0.30 (30% into current window)
    const overlapRatio = 1 - positionRatio; // e.g., 0.70 (70% overlap with previous window)

    const prevWindowCount = this.fixedWindows.get(prevKey) || 0;
    let currentWindowCount = this.fixedWindows.get(currKey) || 0;

    // Chapter 4 Formula: Requests in current window + requests in previous window * overlap percentage
    // Rounded down as shown in Chapter 4 Figure 4-11 (3 + 5 * 0.7 = 6.5 -> rounded down to 6)
    const estimatedBeforeRequest = Math.floor(currentWindowCount + prevWindowCount * overlapRatio);

    let allowed = false;
    let retryAfterSec = 0;
    let finalEstimated = estimatedBeforeRequest;

    if (estimatedBeforeRequest < limit) {
      allowed = true;
      currentWindowCount += 1;
      this.fixedWindows.set(currKey, currentWindowCount);
      finalEstimated = Math.floor(currentWindowCount + prevWindowCount * overlapRatio);
    } else {
      retryAfterSec = Math.max(1, Math.ceil(windowSec * overlapRatio));
    }

    return {
      allowed,
      remaining: Math.max(0, limit - finalEstimated),
      retryAfterSec,
      currentWindowCount,
      prevWindowCount,
      overlapRatio: Number(overlapRatio.toFixed(2)),
      estimatedCount: finalEstimated,
    };
  }

  clearAll() {
    this.tokenBuckets.clear();
    this.leakyBuckets.clear();
    this.fixedWindows.clear();
    this.slidingLogs.clear();
  }
}

module.exports = { InMemoryStorageAdapter };
