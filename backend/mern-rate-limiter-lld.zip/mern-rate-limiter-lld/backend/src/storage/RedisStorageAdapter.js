const { IStorageAdapter } = require('../interfaces/IStorageAdapter');
const {
  TOKEN_BUCKET_LUA,
  LEAKY_BUCKET_LUA,
  FIXED_WINDOW_LUA,
  SLIDING_WINDOW_LOG_LUA,
  SLIDING_WINDOW_COUNTER_LUA,
} = require('../lua/scripts');

/**
 * ============================================================================
 * DISTRIBUTED REDIS STORAGE ADAPTER
 * ============================================================================
 * Executes atomic Lua scripts (`EVAL`) against a centralized Redis cluster so
 * multiple stateless Express API servers stay 100% synchronized with zero race
 * conditions (Chapter 4 Figure 4-16).
 */
class RedisStorageAdapter extends IStorageAdapter {
  /**
   * @param {import('ioredis').Redis} redisClient
   */
  constructor(redisClient) {
    super();
    this.redis = redisClient;
  }

  async runTokenBucket(key, capacity, refillRatePerSec, nowMs, requestedTokens = 1) {
    const [allowed, remaining, retryAfterSec] = await this.redis.eval(
      TOKEN_BUCKET_LUA,
      1,
      key,
      capacity,
      refillRatePerSec,
      nowMs,
      requestedTokens
    );
    return {
      allowed: allowed === 1,
      remaining: Number(remaining),
      retryAfterSec: Number(retryAfterSec),
      tokensLeft: Number(remaining),
    };
  }

  async runLeakyBucket(key, capacity, outflowRatePerSec, nowMs) {
    const [allowed, remaining, retryAfterSec] = await this.redis.eval(
      LEAKY_BUCKET_LUA,
      1,
      key,
      capacity,
      outflowRatePerSec,
      nowMs
    );
    return {
      allowed: allowed === 1,
      remaining: Number(remaining),
      retryAfterSec: Number(retryAfterSec),
      queueSize: capacity - Number(remaining),
    };
  }

  async runFixedWindow(key, limit, windowSec, nowMs) {
    const windowId = Math.floor(nowMs / (windowSec * 1000));
    const windowKey = `${key}:${windowId}`;
    const [allowed, remaining, retryAfterSec, currentCount] = await this.redis.eval(
      FIXED_WINDOW_LUA,
      1,
      windowKey,
      limit,
      windowSec
    );
    return {
      allowed: allowed === 1,
      remaining: Number(remaining),
      retryAfterSec: Number(retryAfterSec),
      currentCount: Number(currentCount),
      windowId,
    };
  }

  async runSlidingWindowLog(key, limit, windowSec, nowMs) {
    const windowMs = windowSec * 1000;
    const uniqueReqId = `${nowMs}-${Math.random().toString(36).slice(2, 8)}`;
    const [allowed, remaining, retryAfterSec, count] = await this.redis.eval(
      SLIDING_WINDOW_LOG_LUA,
      1,
      key,
      limit,
      windowMs,
      nowMs,
      uniqueReqId
    );
    return {
      allowed: allowed === 1,
      remaining: Number(remaining),
      retryAfterSec: Number(retryAfterSec),
      logSize: Number(count),
      timestamps: [],
    };
  }

  async runSlidingWindowCounter(key, limit, windowSec, nowMs) {
    const windowMs = windowSec * 1000;
    const currentWindowId = Math.floor(nowMs / windowMs);
    const prevWindowId = currentWindowId - 1;
    const elapsedInCurrentWindowMs = nowMs - currentWindowId * windowMs;
    const overlapRatio = 1 - elapsedInCurrentWindowMs / windowMs;

    const [allowed, remaining, retryAfterSec, estimatedCount] = await this.redis.eval(
      SLIDING_WINDOW_COUNTER_LUA,
      2,
      `${key}:${currentWindowId}`,
      `${key}:${prevWindowId}`,
      limit,
      windowSec,
      overlapRatio
    );
    return {
      allowed: allowed === 1,
      remaining: Number(remaining),
      retryAfterSec: Number(retryAfterSec),
      overlapRatio: Number(overlapRatio.toFixed(2)),
      estimatedCount: Number(estimatedCount),
    };
  }
}

module.exports = { RedisStorageAdapter };
