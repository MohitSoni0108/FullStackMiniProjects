const { IRateLimiterStrategy, RateLimitDecision } = require('../interfaces/IRateLimiterStrategy');

/**
 * ============================================================================
 * ALGORITHM 3: FIXED WINDOW COUNTER STRATEGY
 * ============================================================================
 * Beginner Summary:
 * - Divides time into fixed windows of `windowSec` seconds (e.g., every 60s).
 * - Each window has an integer counter. Every request increments it by 1.
 * - If `counter > limit`, reject until the current window finishes!
 */
class FixedWindowStrategy extends IRateLimiterStrategy {
  async consume(key, rule, nowMs = Date.now()) {
    const limit = Number(rule.limit || 5);
    const windowSec = Number(rule.windowSec || 60);

    const result = await this.storage.runFixedWindow(
      `rl:fw:${key}`,
      limit,
      windowSec,
      nowMs
    );

    return new RateLimitDecision({
      allowed: result.allowed,
      limit,
      remaining: result.remaining,
      retryAfterSec: result.retryAfterSec,
      algorithm: 'fixed_window',
      debugState: {
        currentCount: result.currentCount,
        windowId: result.windowId,
        windowSec,
      },
    });
  }
}

module.exports = { FixedWindowStrategy };
