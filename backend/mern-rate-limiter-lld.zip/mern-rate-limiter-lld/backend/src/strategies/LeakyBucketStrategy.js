const { IRateLimiterStrategy, RateLimitDecision } = require('../interfaces/IRateLimiterStrategy');

/**
 * ============================================================================
 * ALGORITHM 2: LEAKING BUCKET STRATEGY (Shopify Style)
 * ============================================================================
 * Beginner Summary:
 * - Requests enter a FIFO queue of capacity `bucketSize`.
 * - The bucket leaks (processes) requests at a fixed `outflowRate` per second.
 * - If `queueWaterLevel + 1 > bucketSize`, the bucket overflows and rejects (429).
 */
class LeakyBucketStrategy extends IRateLimiterStrategy {
  async consume(key, rule, nowMs = Date.now()) {
    const capacity = Number(rule.bucketSize || rule.limit || 4);
    const outflowRatePerSec = Number(rule.outflowRate || (rule.limit / (rule.windowSec || 1)));

    const result = await this.storage.runLeakyBucket(
      `rl:lb:${key}`,
      capacity,
      outflowRatePerSec,
      nowMs
    );

    return new RateLimitDecision({
      allowed: result.allowed,
      limit: capacity,
      remaining: result.remaining,
      retryAfterSec: result.retryAfterSec,
      algorithm: 'leaky_bucket',
      debugState: {
        queueSize: result.queueSize,
        capacity,
        outflowRatePerSec,
      },
    });
  }
}

module.exports = { LeakyBucketStrategy };
