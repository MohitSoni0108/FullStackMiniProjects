const { IRateLimiterStrategy, RateLimitDecision } = require('../interfaces/IRateLimiterStrategy');

/**
 * ============================================================================
 * ALGORITHM 5: SLIDING WINDOW COUNTER STRATEGY (Cloudflare Hybrid Formula)
 * ============================================================================
 * Beginner Summary:
 * - Combines Fixed Window's low memory with Sliding Window's smooth boundary!
 * - Formula (Chapter 4 Figure 4-11):
 *   rollingRequests = currentWindowCount + Math.floor(prevWindowCount * overlapPercentage)
 * - In Chapter 4's example: limit = 7/min, prev = 5, curr = 3, position = 30% into minute
 *   -> overlap = 70% (0.7) -> 3 + Math.floor(5 * 0.7) = 3 + 3 = 6 (< 7, Allowed!).
 */
class SlidingWindowCounterStrategy extends IRateLimiterStrategy {
  async consume(key, rule, nowMs = Date.now()) {
    const limit = Number(rule.limit || 7);
    const windowSec = Number(rule.windowSec || 60);

    const result = await this.storage.runSlidingWindowCounter(
      `rl:swc:${key}`,
      limit,
      windowSec,
      nowMs
    );

    return new RateLimitDecision({
      allowed: result.allowed,
      limit,
      remaining: result.remaining,
      retryAfterSec: result.retryAfterSec,
      algorithm: 'sliding_window_counter',
      debugState: {
        currentWindowCount: result.currentWindowCount,
        prevWindowCount: result.prevWindowCount,
        overlapRatio: result.overlapRatio,
        estimatedCount: result.estimatedCount,
      },
    });
  }
}

module.exports = { SlidingWindowCounterStrategy };
