const { IRateLimiterStrategy, RateLimitDecision } = require('../interfaces/IRateLimiterStrategy');

/**
 * ============================================================================
 * ALGORITHM 4: SLIDING WINDOW LOG STRATEGY (Redis Sorted Sets / ClassDojo)
 * ============================================================================
 * Beginner Summary:
 * - Keeps an exact log of millisecond timestamps for every request.
 * - Removes timestamps older than `nowMs - windowMs`.
 * - Adds the new request timestamp (even if rejected, per Chapter 4 Figure 4-10!).
 * - Accepts if `log.length <= limit`, otherwise rejects (429).
 */
class SlidingWindowLogStrategy extends IRateLimiterStrategy {
  async consume(key, rule, nowMs = Date.now()) {
    const limit = Number(rule.limit || 2);
    const windowSec = Number(rule.windowSec || 60);

    const result = await this.storage.runSlidingWindowLog(
      `rl:swl:${key}`,
      limit,
      windowSec,
      nowMs
    );

    return new RateLimitDecision({
      allowed: result.allowed,
      limit,
      remaining: result.remaining,
      retryAfterSec: result.retryAfterSec,
      algorithm: 'sliding_window_log',
      debugState: {
        logSize: result.logSize,
        timestamps: result.timestamps,
        windowSec,
      },
    });
  }
}

module.exports = { SlidingWindowLogStrategy };
