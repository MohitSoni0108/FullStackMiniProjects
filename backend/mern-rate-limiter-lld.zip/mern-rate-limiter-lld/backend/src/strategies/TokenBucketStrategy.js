const { IRateLimiterStrategy, RateLimitDecision } = require('../interfaces/IRateLimiterStrategy');

/**
 * ============================================================================
 * ALGORITHM 1: TOKEN BUCKET STRATEGY (Amazon / Stripe Style)
 * ============================================================================
 * Beginner Summary:
 * - A bucket holds up to `bucketSize` tokens.
 * - Tokens are refilled continuously at `refillRate` tokens per second.
 * - Each request removes 1 token. If `tokens < 1`, the request is throttled (429).
 */
class TokenBucketStrategy extends IRateLimiterStrategy {
  async consume(key, rule, nowMs = Date.now()) {
    const capacity = Number(rule.bucketSize || rule.limit || 4);
    const refillRatePerSec = Number(rule.refillRate || (rule.limit / (rule.windowSec || 1)));

    const result = await this.storage.runTokenBucket(
      `rl:tb:${key}`,
      capacity,
      refillRatePerSec,
      nowMs,
      1
    );

    return new RateLimitDecision({
      allowed: result.allowed,
      limit: capacity,
      remaining: result.remaining,
      retryAfterSec: result.retryAfterSec,
      algorithm: 'token_bucket',
      debugState: {
        tokensLeft: result.tokensLeft,
        capacity,
        refillRatePerSec,
      },
    });
  }
}

module.exports = { TokenBucketStrategy };
