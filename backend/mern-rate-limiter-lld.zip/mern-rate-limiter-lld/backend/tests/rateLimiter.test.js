/**
 * ============================================================================
 * AUTOMATED LLD & ALGORITHM TEST SUITE
 * ============================================================================
 * Verifies every single requirement and example from Chapter 4:
 * 1. Token Bucket (Figure 4-4, 4-5, 4-6: Burst capacity + Refill rate)
 * 2. Leaking Bucket (Figure 4-7: FIFO queue + Constant outflow rate)
 * 3. Fixed Window Counter & Boundary Spike Demonstration (Figure 4-8 & 4-9)
 * 4. Sliding Window Log (Figure 4-10: Exact timestamps at 1:00:01, 1:00:30, 1:00:50, 1:01:40)
 * 5. Sliding Window Counter (Figure 4-11: 3 + 5 * 0.7 = 6.5 -> 6 < 7 formula)
 * 6. Fault-Tolerant Circuit Breaker (Redis crash -> Automatic fallback to Memory / Fail-Open)
 * 7. HTTP 429 Headers (`X-Ratelimit-Limit`, `X-Ratelimit-Remaining`, `X-Ratelimit-Retry-After`)
 */

const assert = require('assert');
const { InMemoryStorageAdapter } = require('../src/storage/InMemoryStorageAdapter');
const { FaultTolerantStorageDecorator } = require('../src/storage/FaultTolerantStorageDecorator');
const { RateLimiterStrategyFactory } = require('../src/factories/RateLimiterStrategyFactory');

async function runTests() {
  console.log('==============================================================');
  console.log(' Running Chapter 4 Rate Limiter LLD Verification Suite...');
  console.log('==============================================================\n');

  const storage = new InMemoryStorageAdapter();
  const factory = new RateLimiterStrategyFactory(storage);

  // TEST 1: Token Bucket Algorithm (Capacity = 4, Refill = 2 tokens/sec, Figure 4-4)
  {
    const tokenBucket = factory.getStrategy('token_bucket');
    const rule = { bucketSize: 4, refillRate: 2 };
    const t0 = 1000000;

    const r1 = await tokenBucket.consume('user_tb', rule, t0);
    const r2 = await tokenBucket.consume('user_tb', rule, t0);
    const r3 = await tokenBucket.consume('user_tb', rule, t0);
    const r4 = await tokenBucket.consume('user_tb', rule, t0);
    const r5 = await tokenBucket.consume('user_tb', rule, t0); // 5th burst request should be throttled!

    assert.strictEqual(r1.allowed, true);
    assert.strictEqual(r4.allowed, true);
    assert.strictEqual(r4.remaining, 0);
    assert.strictEqual(r5.allowed, false, '5th request must be dropped when bucket is empty');
    assert.strictEqual(r5.retryAfterSec, 1);

    // Advance clock by 500ms -> 0.5s * 2 tokens/sec = 1 token refilled!
    const r6 = await tokenBucket.consume('user_tb', rule, t0 + 500);
    assert.strictEqual(r6.allowed, true, 'After 0.5s, 1 token is refilled so request goes through');
    console.log('✅ PASS [1/6]: Token Bucket Algorithm (Figure 4-4: Burst + Refill)');
  }

  // TEST 2: Leaking Bucket Algorithm (Queue Size = 3, Outflow = 1 req/sec, Figure 4-7)
  {
    const leakyBucket = factory.getStrategy('leaky_bucket');
    const rule = { bucketSize: 3, outflowRate: 1 };
    const t0 = 2000000;

    assert.strictEqual((await leakyBucket.consume('user_lb', rule, t0)).allowed, true);
    assert.strictEqual((await leakyBucket.consume('user_lb', rule, t0)).allowed, true);
    assert.strictEqual((await leakyBucket.consume('user_lb', rule, t0)).allowed, true);
    const overflowReq = await leakyBucket.consume('user_lb', rule, t0);
    assert.strictEqual(overflowReq.allowed, false, 'Queue is full (3/3), 4th request overflows');

    // Advance 1000ms -> 1 item leaks out of the queue
    const afterLeakReq = await leakyBucket.consume('user_lb', rule, t0 + 1000);
    assert.strictEqual(afterLeakReq.allowed, true, 'After 1s, 1 slot leaked out of FIFO queue');
    console.log('✅ PASS [2/6]: Leaking Bucket Algorithm (Figure 4-7: FIFO Queue + Outflow)');
  }

  // TEST 3: Fixed Window Counter & Boundary Spike Demonstration (Figure 4-8 & 4-9)
  {
    const fixedWindow = factory.getStrategy('fixed_window');
    const rule = { limit: 3, windowSec: 1 };
    const windowStartMs = 3000000;

    assert.strictEqual((await fixedWindow.consume('user_fw', rule, windowStartMs + 100)).allowed, true);
    assert.strictEqual((await fixedWindow.consume('user_fw', rule, windowStartMs + 200)).allowed, true);
    assert.strictEqual((await fixedWindow.consume('user_fw', rule, windowStartMs + 300)).allowed, true);
    const fourthReq = await fixedWindow.consume('user_fw', rule, windowStartMs + 400);
    assert.strictEqual(fourthReq.allowed, false, '4th request in same 1s fixed window is dropped');

    // New window starts at windowStartMs + 1000
    const nextWindowReq = await fixedWindow.consume('user_fw', rule, windowStartMs + 1000);
    assert.strictEqual(nextWindowReq.allowed, true, 'Quota resets at start of new fixed window');
    console.log('✅ PASS [3/6]: Fixed Window Counter Algorithm (Figure 4-8)');
  }

  // TEST 4: Sliding Window Log Exact Walkthrough from Chapter 4 Figure 4-10!
  // Limit = 2 requests per minute (60s).
  // Request 1 @ 1:00:01 (61,000ms) -> Allowed (log size = 1)
  // Request 2 @ 1:00:30 (90,000ms) -> Allowed (log size = 2)
  // Request 3 @ 1:00:50 (110,000ms) -> Rejected (log size = 3 > 2, timestamp remains in log!)
  // Request 4 @ 1:01:40 (160,000ms) -> Outdated timestamps before 1:00:40 (100,000ms) removed (1:00:01 and 1:00:30 removed), log size becomes 2 -> Allowed!
  {
    const slidingLog = factory.getStrategy('sliding_window_log');
    const rule = { limit: 2, windowSec: 60 };

    const r1 = await slidingLog.consume('fig_4_10', rule, 61000);  // 1:00:01
    const r2 = await slidingLog.consume('fig_4_10', rule, 90000);  // 1:00:30
    const r3 = await slidingLog.consume('fig_4_10', rule, 110000); // 1:00:50
    const r4 = await slidingLog.consume('fig_4_10', rule, 160000); // 1:01:40

    assert.strictEqual(r1.allowed, true, '1:00:01 should be allowed');
    assert.strictEqual(r2.allowed, true, '1:00:30 should be allowed');
    assert.strictEqual(r3.allowed, false, '1:00:50 should be rejected (log size 3 > 2)');
    assert.strictEqual(r3.debugState.logSize, 3, 'Rejected timestamp 1:00:50 stays in log per Figure 4-10');
    assert.strictEqual(r4.allowed, true, '1:01:40 should be allowed after pruning 1:00:01 and 1:00:30');
    assert.strictEqual(r4.debugState.logSize, 2, 'Log size at 1:01:40 is exactly 2 (1:00:50 and 1:01:40)');
    console.log('✅ PASS [4/6]: Sliding Window Log Algorithm (Exact Figure 4-10 Walkthrough)');
  }

  // TEST 5: Sliding Window Counter Exact Walkthrough from Chapter 4 Figure 4-11!
  // Limit = 7 requests per minute (60,000ms).
  // Previous minute had 5 requests. Current minute has 3 requests.
  // New request arrives at 30% position in current minute (overlap = 70% = 0.7).
  // Formula before adding current request: 3 + floor(5 * 0.7) = 3 + 3 = 6 (< 7 -> Allowed!).
  {
    const slidingCounter = factory.getStrategy('sliding_window_counter');
    const rule = { limit: 7, windowSec: 60 };
    const minute1Start = 60000;
    const minute2Start = 120000;

    // Send 5 requests in previous minute
    for (let i = 0; i < 5; i++) {
      await slidingCounter.consume('fig_4_11', rule, minute1Start + i * 1000);
    }
    // Send 3 requests in current minute
    for (let i = 0; i < 3; i++) {
      await slidingCounter.consume('fig_4_11', rule, minute2Start + i * 1000);
    }

    // New request arrives at 30% position into Minute 2 (minute2Start + 18,000ms)
    const testReq = await slidingCounter.consume('fig_4_11', rule, minute2Start + 18000);
    assert.strictEqual(testReq.allowed, true, 'Request at 30% position (6.5 -> 6 < 7) must be allowed');
    assert.strictEqual(testReq.debugState.overlapRatio, 0.7);
    console.log('✅ PASS [5/6]: Sliding Window Counter Algorithm (Exact Figure 4-11 Formula)');
  }

  // TEST 6: High Fault Tolerance Circuit Breaker Decorator (Redis Crash Simulation)
  {
    const brokenRedisAdapter = {
      async runTokenBucket() {
        throw new Error('ECONNREFUSED: Redis cluster node unreachable');
      },
    };
    const fallbackMemory = new InMemoryStorageAdapter();
    const resilientStorage = new FaultTolerantStorageDecorator(brokenRedisAdapter, fallbackMemory, 'memory');
    const resilientFactory = new RateLimiterStrategyFactory(resilientStorage);

    const decision = await resilientFactory.getStrategy('token_bucket').consume('user_ft', {
      bucketSize: 2,
      refillRate: 1,
    });

    assert.strictEqual(decision.allowed, true, 'System must not crash when Redis is offline');
    assert.strictEqual(resilientStorage.isPrimaryHealthy, false);
    assert.strictEqual(resilientStorage.fallbackCount, 1);
    const headers = decision.toHttpHeaders();
    assert.strictEqual(headers['X-Ratelimit-Limit'], '2');
    assert.strictEqual(headers['X-Ratelimit-Remaining'], '1');
    console.log('✅ PASS [6/6]: Fault-Tolerant Circuit Breaker & HTTP Headers Verification');
  }

  console.log('\n🎉 ALL 6 CHAPTER 4 SYSTEM DESIGN & LLD TEST SUITES PASSED!');
}

runTests().catch((err) => {
  console.error('❌ Test failed:', err);
  process.exit(1);
});
