import React, { useState } from 'react';
import { ResilientApiClient } from './api/clientWithBackoff';

const client = new ResilientApiClient({ baseUrl: 'http://localhost:5000/api' });

export default function App() {
  const [logs, setLogs] = useState([]);
  const [endpoint, setEndpoint] = useState('/v1/posts');
  const [userId, setUserId] = useState('user_101');

  async function sendTestRequest() {
    const res = await client.request(endpoint, {
      method: 'POST',
      headers: { 'x-user-id': userId },
      body: JSON.stringify({ userId, content: 'Hello from MERN client!' }),
    });
    setLogs((prev) => [{ time: new Date().toLocaleTimeString(), ...res }, ...prev]);
  }

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', padding: 24, maxWidth: 960, margin: '0 auto' }}>
      <h1>ShieldGate MERN Distributed Rate Limiter Dashboard</h1>
      <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
        <select value={endpoint} onChange={(e) => setEndpoint(e.target.value)}>
          <option value="/v1/posts">POST /api/v1/posts (Token Bucket: 2/sec)</option>
          <option value="/v1/auth/login">POST /api/v1/auth/login (Sliding Window Counter: 5/min)</option>
          <option value="/v1/rewards/claim">POST /api/v1/rewards/claim (Sliding Window Log: 5/week)</option>
          <option value="/v1/accounts">POST /api/v1/accounts (Fixed Window: 10/day)</option>
          <option value="/v1/messages/marketing">POST /api/v1/messages/marketing (Leaky Bucket + Queue)</option>
        </select>
        <input value={userId} onChange={(e) => setUserId(e.target.value)} placeholder="User ID" />
        <button onClick={sendTestRequest}>Send Request</button>
      </div>
      <pre style={{ background: '#0f172a', color: '#e2e8f0', padding: 16, borderRadius: 8 }}>
        {JSON.stringify(logs, null, 2)}
      </pre>
    </div>
  );
}
