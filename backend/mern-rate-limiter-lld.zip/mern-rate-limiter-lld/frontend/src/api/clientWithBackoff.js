/**
 * ============================================================================
 * CHAPTER 4 STEP 4: CLIENT BEST PRACTICES TO AVOID BEING RATE LIMITED
 * ============================================================================
 * Chapter 4 recommends 4 client-side best practices:
 * 1. Use client cache to avoid making frequent API calls.
 * 2. Understand the limit and do not send too many requests in a short time frame.
 * 3. Include code to catch exceptions or errors so your client can gracefully recover.
 * 4. Add sufficient back-off time to retry logic.
 */
export class ResilientApiClient {
  constructor({ baseUrl = 'http://localhost:5000/api', maxRetries = 3, baseDelayMs = 500 } = {}) {
    this.baseUrl = baseUrl;
    this.maxRetries = maxRetries;
    this.baseDelayMs = baseDelayMs;
    this.cache = new Map(); // Client-side TTL cache
  }

  /**
   * Sends a request with automatic Client Caching (for GET) and Exponential Backoff + Jitter on HTTP 429
   */
  async request(endpoint, options = {}, cacheTtlMs = 5000) {
    const cacheKey = `${options.method || 'GET'}:${endpoint}:${JSON.stringify(options.body || {})}`;

    // Best Practice 1: Use client cache for read requests
    if ((options.method || 'GET') === 'GET' && this.cache.has(cacheKey)) {
      const cached = this.cache.get(cacheKey);
      if (Date.now() < cached.expiresAt) {
        return { ...cached.data, fromClientCache: true };
      }
    }

    let attempt = 0;
    while (attempt <= this.maxRetries) {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
        ...options,
      });

      const rateLimitHeaders = {
        limit: response.headers.get('X-Ratelimit-Limit'),
        remaining: response.headers.get('X-Ratelimit-Remaining'),
        retryAfter: response.headers.get('X-Ratelimit-Retry-After'),
      };

      const data = await response.json();

      if (response.status !== 429) {
        if ((options.method || 'GET') === 'GET') {
          this.cache.set(cacheKey, { data, expiresAt: Date.now() + cacheTtlMs });
        }
        return { status: response.status, data, rateLimitHeaders, attemptsUsed: attempt + 1 };
      }

      // Best Practice 3 & 4: Catch HTTP 429 and back off using X-Ratelimit-Retry-After + Exponential Jitter
      attempt += 1;
      if (attempt > this.maxRetries) {
        return { status: 429, data, rateLimitHeaders, attemptsUsed: attempt };
      }

      const serverRetrySec = Number(rateLimitHeaders.retryAfter || 1);
      const exponentialMs = Math.max(serverRetrySec * 1000, this.baseDelayMs * Math.pow(2, attempt));
      const jitterMs = Math.floor(Math.random() * 250);
      await new Promise((resolve) => setTimeout(resolve, exponentialMs + jitterMs));
    }
  }
}
